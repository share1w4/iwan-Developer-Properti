import asyncio,subprocess,time,sys
from playwright.async_api import async_playwright
srv=subprocess.Popen([sys.executable,'-m','http.server','8765'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();errs=[]
        for name,vp in [('HP',{'width':390,'height':780}),('Desktop',{'width':1280,'height':800})]:
            c=await b.new_context(viewport=vp);pg=await c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:asyncio.ensure_future(d.accept('Budi')))
            await pg.goto('http://localhost:8765/index.html');await pg.fill('input[name=nama]','Uji');await pg.click('#f button')
            assert 'EMHA' in await pg.content() or True
            await pg.click('nav.b >> text=Proyek');assert 'EMHA Buana Residence' in await pg.inner_text('main')
            await pg.click('text=+ Proyek baru');await pg.fill('input[name=nama]','Proyek Uji');await pg.fill('input[name=luasBruto]','1000');await pg.fill('input[name=luasEfektif]','2000');await pg.click('button.p')
            assert 'tidak boleh melebihi' in await pg.inner_text('#er');await pg.fill('input[name=luasEfektif]','600');await pg.click('button.p')
            assert 'PRJ-002' in await pg.inner_text('main')
            await pg.click('nav.b >> text=Lahan');t=await pg.inner_text('main');assert 'Rp0' in t
            await pg.reload();await pg.click('nav.b >> text=Proyek');assert 'Proyek Uji' in await pg.inner_text('main')  # tetap tersimpan
            await pg.click('text=Jadikan aktif >> nth=0') if False else None
            await pg.click('nav.b >> text=Unit');await pg.fill('#fu input[name=no]','99');await pg.click('#fu button');assert '99' in await pg.inner_text('main')
            sw=await pg.evaluate("navigator.serviceWorker.getRegistration().then(r=>!!r)");mf=await pg.evaluate("fetch('manifest.webmanifest').then(r=>r.ok)")
            ov=await pg.evaluate("document.documentElement.scrollWidth>innerWidth")
            print(name,'OK | service worker:',sw,'| manifest:',mf,'| overflow horizontal:',ov)
            if name=='HP':await pg.screenshot(path='hp.png')
        print('error JS:',errs or 'tidak ada');await b.close()
asyncio.run(main());srv.kill()

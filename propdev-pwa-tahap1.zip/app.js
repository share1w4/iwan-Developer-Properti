const {rp,can,nilaiTanah,ringkasan}=Core,KEY='propdev_v1',$=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const MENU=[['Dashboard','#/','▦',1],['Data Proyek','#/proyek','▤',1],['Lahan dan Site Plan','#/lahan','◩',2],['Perizinan','#/x/Perizinan',' ',2],['Desain dan Gambar','#/x/Desain',' ',3],['RAB dan RAP','#/x/RAB',' ',3],['Pengadaan Material','#/x/Pengadaan',' ',3],['Progres Konstruksi','#/x/Progres',' ',3],['Keuangan','#/x/Keuangan',' ',4],['Marketing dan CRM','#/x/CRM',' ',5],['Penjualan dan Booking','#/unit','▥',2],['Serah Terima dan Garansi','#/x/Serah',' ',5],['Laporan','#/x/Laporan',' ',4],['Pengaturan','#/set','⚙',1]];
const BOTTOM=[['#/','▦','Dashboard'],['#/proyek','▤','Proyek'],['#/lahan','◩','Lahan'],['#/unit','▥','Unit'],['#/set','⚙','Akun']];
function demo(){return{session:null,aktif:1,projects:[{id:1,kode:'PRJ-001',nama:'EMHA Buana Residence',badan:'PT Contoh Developer (SIMULASI)',alamat:'Ciberem, Sumbang',kota:'Banyumas',provinsi:'Jawa Tengah',jenis:'Rumah subsidi',status:'Aktif',luasBruto:11556,luasEfektif:7800,unitRencana:115,mulai:'2026-01-15',target:'2027-06-30',pic:'Project Manager (SIMULASI)',investasi:12000000000,hargaTanah:350000,catatan:'Data SIMULASI untuk uji coba.',log:[]}],
units:Array.from({length:12},(_,i)=>({id:i+1,projectId:1,blok:'A',no:String(i+1),luasTanah:84,luasBangunan:30,tipe:'30/60',harga:165000000,status:i<4?'Tersedia':i<6?'Booking':i<8?'Terjual':'Belum dipasarkan',pembeli:i>=4&&i<8?'Pembeli Contoh '+(i-3):'',tglBooking:i>=4&&i<6?'2026-10-01':''}))};}
let S=load();function load(){try{return JSON.parse(localStorage.getItem(KEY))||demo()}catch(e){return demo()}}
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){alert('Penyimpanan penuh atau diblokir browser.')}};
const proj=()=>S.projects.find(p=>p.id===S.aktif)||S.projects[0];
const log=(p,t)=>{p.log=p.log||[];p.log.unshift(new Date().toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})+' – '+S.session.role+': '+t)};
const field=(l,n,v='',t='text',x='')=>`<label>${l}<input name="${n}" type="${t}" value="${esc(v)}" ${x}></label>`;
function sel(l,n,opts,v){return `<label>${l}<select name="${n}">${opts.map(o=>`<option ${o===v?'selected':''}>${esc(o)}</option>`).join('')}</select></label>`}
const num=(f,n)=>Number(f.elements[n].value)||0;
function render(){
 if(!S.session)return login();
 const h=location.hash||'#/',[,r,a]=h.split('/');
 $('#us').textContent=S.session.role;
 $('#bn').innerHTML=BOTTOM.map(b=>`<a href="${b[0]}" class="${h===b[0]?'on':''}"><b>${b[1]}</b>${b[2]}</a>`).join('');
 $('#drc').innerHTML=MENU.map(m=>`<a href="${m[1]}">${m[0]}<small>${m[3]>1&&m[1].includes('/x/')?'Tahap '+m[3]:''}</small></a>`).join('');
 const V={'':dash,proyek:listProyek,formproyek:()=>formProyek(a),lahan,unit,set:pengaturan,x:()=>belum(a)};
 $('#jd').textContent='PROPDEV';$('#app').innerHTML=(V[r||'']||dash)();scrollTo(0,0);
}
function login(){$('#bn').innerHTML='';$('#us').textContent='';
 $('#app').innerHTML=`<div class="card"><h2>Masuk (mode demo)</h2><p class="k">Mode demo: data tersimpan hanya di browser HP ini, bukan di database permanen. Login aman dengan kata sandi akan tersedia setelah Supabase dihubungkan (Tahap 6).</p>
 <form id="f">${field('Nama','nama','','text','required')}${sel('Peran','role',Object.keys(Core.ROLES),'Direktur')}<div class="row"><button class="p">Masuk</button></div></form></div>`;
 $('#f').onsubmit=e=>{e.preventDefault();S.session={nama:e.target.nama.value.trim(),role:e.target.role.value};save();render()}}
function dash(){const p=proj(),r=ringkasan(S,null),pr=ringkasan(S,p&&p.id);
 return `<h2>Dashboard</h2>${r.peringatan.map(w=>`<div class="card warn">⚠ ${esc(w)}</div>`).join('')}
 <div class="grid"><div class="card"><div class="k">Proyek aktif</div><div class="v">${r.proyekAktif}</div></div>
 <div class="card"><div class="k">Luas lahan</div><div class="v">${r.luasLahan.toLocaleString('id-ID')} m²</div></div>
 <div class="card"><div class="k">Rencana investasi</div><div class="v">${rp(r.investasi)}</div></div>
 <div class="card"><div class="k">Nilai tanah (asumsi)</div><div class="v">${rp(r.nilaiTanah)}</div></div>
 <div class="card"><div class="k">Unit tersedia / booking</div><div class="v">${r.tersedia} / ${r.booking}</div></div>
 <div class="card"><div class="k">Unit terjual</div><div class="v">${r.terjual}</div></div></div>
 <div class="card" style="margin-top:10px"><div class="k">Pendapatan penjualan (unit terjual dan sesudahnya)</div><div class="v">${rp(r.pendapatan)}</div>
 <div class="k" style="margin-top:8px">Penjualan ${r.terjual} dari ${r.unitDirencanakan} unit rencana</div><div class="bar"><i style="width:${r.unitDirencanakan?Math.min(100,r.terjual/r.unitDirencanakan*100):0}%"></i></div></div>
 <div class="card"><div class="k">Belum tersedia hingga tahap berikutnya</div><div>Progres pembangunan, RAB/RAP, realisasi biaya, arus kas, laba/rugi, tagihan, dan perizinan akan muncul di dashboard setelah modulnya dibangun. Angka tidak ditampilkan agar tidak menyesatkan.</div></div>`}
function listProyek(){const w=can(S.session.role,'proyek');
 return `<h2>Data Proyek</h2>${w?'<div class="row" style="margin:0 0 10px"><a href="#/formproyek/baru"><button class="p">+ Proyek baru</button></a></div>':''}
 ${S.projects.length?S.projects.map(p=>`<div class="card"><b>${esc(p.nama)}</b> <span class="tag">${esc(p.kode)}</span><div class="k">${esc(p.jenis)} · ${esc(p.kota)}, ${esc(p.provinsi)} · ${esc(p.status)}</div>
 <div class="k">Lahan ${(+p.luasBruto).toLocaleString('id-ID')} m² · ${p.unitRencana} unit · Nilai tanah ${rp(nilaiTanah(p.luasBruto,p.hargaTanah))} <span class="sim">asumsi</span></div>
 <div class="row"><button class="s" onclick="pilih(${p.id})">${p.id===S.aktif?'✓ Proyek aktif':'Jadikan aktif'}</button>${w?`<a href="#/formproyek/${p.id}"><button class="s">Ubah</button></a><button class="d" onclick="hapusP(${p.id})">Hapus</button>`:''}</div></div>`).join(''):'<div class="card">Belum ada proyek. Tekan "Proyek baru" untuk memulai.</div>'}`}
window.pilih=id=>{S.aktif=id;save();render()};
window.hapusP=id=>{const p=S.projects.find(x=>x.id===id);if(!confirm('Hapus proyek "'+p.nama+'" beserta semua unitnya? Tindakan ini tidak bisa dibatalkan.'))return;S.projects=S.projects.filter(x=>x.id!==id);S.units=S.units.filter(u=>u.projectId!==id);S.aktif=S.projects[0]?.id;save();render()};
function formProyek(id){if(!can(S.session.role,'proyek'))return '<div class="err">Peran Anda tidak boleh mengubah proyek.</div>';
 const p=id==='baru'?{jenis:'Rumah subsidi',status:'Perencanaan',provinsi:'Jawa Tengah'}:S.projects.find(x=>x.id==id);if(!p)return '<div class="err">Proyek tidak ditemukan.</div>';
 setTimeout(()=>{$('#fp').onsubmit=e=>{e.preventDefault();const f=e.target,d={nama:f.nama.value,badan:f.badan.value,alamat:f.alamat.value,kota:f.kota.value,provinsi:f.provinsi.value,jenis:f.jenis.value,status:f.status.value,luasBruto:num(f,'luasBruto'),luasEfektif:num(f,'luasEfektif'),unitRencana:num(f,'unitRencana'),mulai:f.mulai.value,target:f.target.value,pic:f.pic.value,investasi:num(f,'investasi'),hargaTanah:num(f,'hargaTanah'),catatan:f.catatan.value};
 const er=Core.validasiProyek(d);if(er.length){$('#er').innerHTML=er.map(x=>`<div class="err">${esc(x)}</div>`).join('');return}
 if(id==='baru'){const n={id:Date.now(),kode:Core.nextKode(S.projects),log:[],...d};S.projects.push(n);S.aktif=n.id;log(n,'Proyek dibuat')}else{Object.assign(p,d);log(p,'Data proyek diubah')}
 save();location.hash='#/proyek'}},0);
 return `<h2>${id==='baru'?'Proyek baru':'Ubah proyek'}</h2><form id="fp" class="card"><div id="er"></div>${field('Nama proyek','nama',p.nama,'text','required')}${field('Nama badan usaha','badan',p.badan)}${field('Alamat','alamat',p.alamat)}${field('Kabupaten/kota','kota',p.kota)}${field('Provinsi','provinsi',p.provinsi)}
 ${sel('Jenis proyek','jenis',['Rumah subsidi','Rumah komersial','Cluster','Kavling','Ruko','Apartemen','Properti lainnya'],p.jenis)}${sel('Status','status',['Perencanaan','Aktif','Ditunda','Selesai'],p.status)}
 ${field('Luas lahan bruto (m²)','luasBruto',p.luasBruto,'number','step="any" min="0"')}${field('Luas efektif (m²)','luasEfektif',p.luasEfektif||0,'number','step="any" min="0"')}${field('Unit direncanakan','unitRencana',p.unitRencana||0,'number','min="0"')}
 ${field('Tanggal mulai','mulai',p.mulai,'date')}${field('Target selesai','target',p.target,'date')}${field('Penanggung jawab','pic',p.pic)}${field('Nilai investasi (Rp)','investasi',p.investasi||0,'number','min="0"')}${field('Harga tanah per m² (Rp)','hargaTanah',p.hargaTanah||0,'number','min="0"')}
 <label>Catatan<textarea name="catatan" rows="3">${esc(p.catatan)}</textarea></label><div class="row"><button class="p">Simpan</button><a href="#/proyek"><button type="button" class="s">Batal</button></a></div>
 ${(p.log||[]).length?`<h3>Riwayat perubahan</h3>${p.log.slice(0,8).map(l=>`<div class="k">${esc(l)}</div>`).join('')}`:''}</form>`}
function lahan(){const p=proj();if(!p)return '<div class="card">Buat proyek terlebih dahulu.</div>';
 const U=S.units.filter(u=>u.projectId===p.id),pk=U.reduce((a,u)=>a+(+u.luasTanah||0),0),sisa=p.luasBruto-pk,ef=p.luasEfektif||0;
 return `<h2>Lahan: ${esc(p.nama)}</h2><div class="card"><div class="k">Nilai tanah = luas × harga per m² <span class="sim">asumsi perencanaan, bukan nilai transaksi</span></div>
 <div class="v">${rp(nilaiTanah(p.luasBruto,p.hargaTanah))}</div><div class="k">${(+p.luasBruto).toLocaleString('id-ID')} m² × ${rp(p.hargaTanah)}</div></div>
 <div class="card"><b>Konsistensi luas</b><div class="k">Luas bruto</div><div>${(+p.luasBruto).toLocaleString('id-ID')} m²</div><div class="k">Luas efektif (dapat dikavling)</div><div>${ef.toLocaleString('id-ID')} m²</div>
 <div class="k">Total luas tanah semua kavling/unit tercatat (${U.length})</div><div>${pk.toLocaleString('id-ID')} m²</div>
 <div class="k">Luas efektif belum teralokasi</div><div style="${ef-pk<0?'color:var(--r);font-weight:700':''}">${(ef-pk).toLocaleString('id-ID')} m² ${ef-pk<0?'⚠ kavling melebihi luas efektif':''}</div>
 <div class="k">Selisih bruto − kavling (jalan, fasum, RTH, dll.)</div><div>${sisa.toLocaleString('id-ID')} m²</div></div>
 <div class="card"><b>Denah kavling sederhana</b><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(54px,1fr));gap:6px;margin-top:8px">${U.map(u=>`<div title="${esc(u.status)}" style="border-radius:6px;padding:6px 2px;text-align:center;font-size:12px;color:#fff;background:${warna(u.status)}">${esc(u.blok)}-${esc(u.no)}</div>`).join('')||'<span class="k">Belum ada unit.</span>'}</div>
 <div class="k" style="margin-top:8px">Hijau tua: tersedia · oranye: dipesan · abu-abu: belum dipasarkan · biru: terjual dan seterusnya</div></div>
 <div class="card k">Impor/ekspor CSV, DXF/PDF/GIS, dan editor layout lengkap belum tersedia; direncanakan di Tahap 2.</div>`}
const warna=s=>s==='Tersedia'?'#0f4c3a':['Booking','Dalam proses pemesanan'].includes(s)?'#d9731a':Core.TERJUAL.includes(s)?'#2a5d9f':'#8a948f';
function unit(){const p=proj();if(!p)return '<div class="card">Buat proyek terlebih dahulu.</div>';const w=can(S.session.role,'unit');
 const U=S.units.filter(u=>u.projectId===p.id);
 return `<h2>Unit: ${esc(p.nama)}</h2>${w?`<form id="fu" class="card"><b>Tambah unit</b><div id="eru"></div>${field('Blok','blok','A')}${field('Nomor unit','no','','text','required')}${field('Luas tanah (m²)','lt',84,'number','step="any"')}${field('Luas bangunan (m²)','lb',30,'number','step="any"')}${field('Tipe','tipe','30/60')}${field('Harga dasar (Rp)','harga',165000000,'number')}<div class="row"><button class="p">Simpan unit</button></div></form>`:''}
 ${U.length?U.map(u=>`<div class="card"><b>${esc(u.blok)}-${esc(u.no)}</b> <span class="tag">${esc(u.status)}</span><div class="k">Tipe ${esc(u.tipe)} · LT ${u.luasTanah} m² · LB ${u.luasBangunan} m² · ${rp(u.harga)}</div>${u.pembeli?`<div class="k">Pembeli: ${esc(u.pembeli)} · booking ${esc(u.tglBooking)}</div>`:''}
 ${w?`<div class="row"><select id="st${u.id}" style="flex:1">${Core.STATUS_UNIT.map(s=>`<option ${s===u.status?'selected':''}>${s}</option>`).join('')}</select><button class="s" onclick="ubah(${u.id})">Ubah status</button><button class="d" onclick="hapusU(${u.id})">Hapus</button></div>`:''}</div>`).join(''):'<div class="card">Belum ada unit. Tambahkan unit pertama.</div>'}`}
document.addEventListener('submit',e=>{if(e.target.id!=='fu')return;e.preventDefault();const f=e.target,p=proj(),u={id:Date.now(),projectId:p.id,blok:f.blok.value.trim(),no:f.no.value.trim(),luasTanah:num(f,'lt'),luasBangunan:num(f,'lb'),tipe:f.tipe.value,harga:num(f,'harga'),status:'Belum dipasarkan',pembeli:'',tglBooking:''};
 const er=Core.validasiUnit(u,S.units);if(er.length){$('#eru').innerHTML=er.map(x=>`<div class="err">${esc(x)}</div>`).join('');return}S.units.push(u);log(p,'Unit '+u.blok+'-'+u.no+' ditambahkan');save();render()});
window.ubah=id=>{const u=S.units.find(x=>x.id===id),s=$('#st'+id).value;let b;
 if(s==='Booking'&&!u.pembeli){b=prompt('Nama pembeli untuk booking:');if(!b)return}
 const r=Core.ubahStatus(u,s,b||u.pembeli);if(!r.ok){alert(r.error);render();return}log(proj(),'Unit '+u.blok+'-'+u.no+' → '+s);save();render()};
window.hapusU=id=>{if(!confirm('Hapus unit ini?'))return;S.units=S.units.filter(u=>u.id!==id);save();render()};
function belum(n){return `<div class="card"><h2>${esc(decodeURIComponent(n||''))}</h2>Modul ini belum dibangun. Lihat jadwal tahap pada menu samping. Tidak ada data palsu yang ditampilkan.</div>`}
function pengaturan(){return `<h2>Akun dan data</h2><div class="card"><b>${esc(S.session.nama)}</b><div class="k">${esc(S.session.role)} · mode demo (data di browser ini)</div>
 <div class="row"><button class="s" onclick="keluar()">Keluar</button><button class="s" onclick="cadangan()">Unduh cadangan (JSON)</button><button class="d" onclick="reset()">Reset ke data demo</button></div></div>
 <div class="card k">Cadangan manual: unduh JSON secara berkala. Audit log penuh, backup otomatis, dan database permanen menyusul di Tahap 6.</div>`}
window.keluar=()=>{S.session=null;save();render()};
window.cadangan=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(S,null,1)],{type:'application/json'}));a.download='propdev-cadangan-'+new Date().toISOString().slice(0,10)+'.json';a.click()};
window.reset=()=>{if(confirm('Semua data lokal diganti data demo. Lanjutkan?')){S=demo();save();render()}};
$('#mn').onclick=()=>$('#dr').classList.add('open');$('#dr').onclick=()=>$('#dr').classList.remove('open');
addEventListener('hashchange',render);render();
if('serviceWorker' in navigator)addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));

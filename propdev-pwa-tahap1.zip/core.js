(function(g){
const STATUS_UNIT=['Belum dipasarkan','Tersedia','Dalam proses pemesanan','Booking','Terjual','Akad/kontrak','Dalam pembangunan','Siap serah terima','Sudah diserahterimakan','Dibatalkan'];
const TERJUAL=['Terjual','Akad/kontrak','Dalam pembangunan','Siap serah terima','Sudah diserahterimakan'];
const KUNCI=['Booking','Dalam proses pemesanan'].concat(TERJUAL);
const ROLES={'Super Admin':'rw','Direktur':'rw','Project Manager':'rw','Arsitek/Engineer':'r','QS/RAB':'r','Finance':'r','Marketing':'u','Purchasing':'r','Pelaksana Lapangan':'r','Viewer':'r'};
// r=lihat saja, u=lihat + ubah unit, rw=lihat + ubah semua
const can=(role,aksi)=>{const p=ROLES[role]||'r';return aksi==='proyek'?p==='rw':aksi==='unit'?(p==='rw'||p==='u'):false;};
const rp=n=>'Rp'+Math.round(Number(n)||0).toString().replace(/\B(?=(\d{3})+(?!\d))/g,'.');
const nilaiTanah=(luas,harga)=>Math.max(0,Number(luas)||0)*Math.max(0,Number(harga)||0);
const nextKode=list=>{const m=list.reduce((a,p)=>Math.max(a,parseInt((p.kode||'').split('-')[1])||0),0);return 'PRJ-'+String(m+1).padStart(3,'0');};
function validasiProyek(p){const e=[];
 if(!p.nama||!p.nama.trim())e.push('Nama proyek wajib diisi.');
 if(!(p.luasBruto>0))e.push('Luas lahan bruto harus lebih dari 0.');
 if(p.luasEfektif<0||p.luasEfektif>p.luasBruto)e.push('Luas efektif tidak boleh melebihi luas bruto.');
 if(!(p.unitRencana>=0))e.push('Jumlah unit tidak valid.');
 if(p.mulai&&p.target&&p.target<p.mulai)e.push('Target selesai tidak boleh sebelum tanggal mulai.');
 return e;}
function validasiUnit(u,units){const e=[];
 if(!u.no||!u.no.trim())e.push('Nomor unit wajib diisi.');
 else if(units.some(x=>x.projectId===u.projectId&&x.blok===u.blok&&x.no===u.no&&x.id!==u.id))e.push('Nomor unit sudah ada pada blok tersebut.');
 if(!(u.luasTanah>0))e.push('Luas tanah harus lebih dari 0.');
 if(!(u.harga>=0))e.push('Harga tidak valid.');
 return e;}
// Ubah status unit. Mengembalikan {ok,error}. Mencegah booking ganda.
function ubahStatus(unit,status,pembeli){
 if(!STATUS_UNIT.includes(status))return{ok:false,error:'Status tidak dikenal.'};
 if(KUNCI.includes(status)&&!KUNCI.includes(unit.status)&&unit.status!=='Tersedia'&&unit.status!=='Belum dipasarkan')return{ok:false,error:'Unit tidak bisa dipesan dari status "'+unit.status+'".'};
 if(['Booking','Dalam proses pemesanan'].includes(status)&&KUNCI.includes(unit.status)&&unit.pembeli&&pembeli&&unit.pembeli!==pembeli)return{ok:false,error:'Unit sudah dipesan oleh '+unit.pembeli+'. Booking ganda ditolak.'};
 if(status==='Booking'&&!(pembeli||unit.pembeli))return{ok:false,error:'Nama pembeli wajib diisi untuk booking.'};
 unit.status=status;
 if(status==='Booking'||status==='Dalam proses pemesanan'){unit.pembeli=pembeli||unit.pembeli;unit.tglBooking=unit.tglBooking||new Date().toISOString().slice(0,10);}
 if(status==='Tersedia'||status==='Belum dipasarkan'||status==='Dibatalkan'){unit.pembeli='';unit.tglBooking='';}
 return{ok:true};}
function ringkasan(state,projectId){
 const P=state.projects.filter(p=>!projectId||p.id===projectId);
 const ids=P.map(p=>p.id);const U=state.units.filter(u=>ids.includes(u.projectId));
 const c=s=>U.filter(u=>s.includes(u.status)).length;
 const total=U.length,terjual=c(TERJUAL);
 return{proyekAktif:P.filter(p=>p.status==='Aktif').length,jumlahProyek:P.length,
 luasLahan:P.reduce((a,p)=>a+(+p.luasBruto||0),0),investasi:P.reduce((a,p)=>a+(+p.investasi||0),0),
 nilaiTanah:P.reduce((a,p)=>a+nilaiTanah(p.luasBruto,p.hargaTanah),0),
 unitTotal:total,tersedia:c(['Tersedia']),booking:c(['Booking','Dalam proses pemesanan']),terjual:terjual,akad:c(['Akad/kontrak']),
 pendapatan:U.filter(u=>TERJUAL.includes(u.status)).reduce((a,u)=>a+(+u.harga||0),0),
 unitDirencanakan:P.reduce((a,p)=>a+(+p.unitRencana||0),0),
 peringatan:P.filter(p=>p.target&&p.status==='Aktif'&&p.target<new Date().toISOString().slice(0,10)).map(p=>p.nama+' melewati target selesai ('+p.target+')')};}
const api={STATUS_UNIT,TERJUAL,ROLES,can,rp,nilaiTanah,nextKode,validasiProyek,validasiUnit,ubahStatus,ringkasan};
if(typeof module!=='undefined')module.exports=api;else g.Core=api;
})(this);

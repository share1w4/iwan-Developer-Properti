# PROPDEV Indonesia – Tahap 1 (PWA)

Aplikasi web mobile-first yang bisa dipasang di layar utama HP Android. Tanpa instalasi Node/npm: hanya file statis.

## Status Tahap 1
**Sudah jadi dan diuji:** login demo berbasis peran, dashboard dari data tersimpan, CRUD proyek (kode otomatis, validasi, riwayat perubahan, konfirmasi hapus), data unit + ubah status + pencegahan booking ganda, nilai tanah (luas × harga/m²), pengecekan luas efektif vs kavling, denah kavling sederhana, cadangan JSON, PWA (manifest + service worker + offline).

**Belum ada:** database permanen/Supabase, login aman dengan kata sandi, RLS, RAB/RAP, perizinan, progres, keuangan, CRM, serah terima, laporan PDF/Excel, upload dokumen, grafik. Menu-menu itu hanya menampilkan "belum dibangun". Aplikasi juga belum online dan belum berbentuk APK.

**Catatan penting:** data saat ini tersimpan di browser HP (localStorage), bukan database. Menghapus data situs/browser akan menghapus data. Unduh cadangan JSON secara berkala (menu Akun). Semua data contoh (EMHA Buana Residence) berlabel SIMULASI. Peran pengguna di mode demo hanya pemilih peran, bukan keamanan sungguhan.

## Menjalankan di komputer Windows (untuk mencoba)
1. Ekstrak ZIP. 2. Instal Python dari python.org (centang "Add to PATH").
3. Buka folder di Command Prompt, jalankan: `python -m http.server 8000`
4. Buka http://localhost:8000 di Chrome.

(Service worker/PWA butuh `localhost` atau HTTPS; membuka file index.html langsung tidak akan memasang PWA.)

## Memasang di HP Android
PWA harus diakses lewat **HTTPS**. Cara termudah gratis: unggah seluruh isi folder ke Netlify Drop (app.netlify.com/drop), GitHub Pages, atau Cloudflare Pages. Buka alamatnya di Chrome Android → menu ⋮ → **Instal aplikasi** / **Tambahkan ke layar utama**.

## Pengujian
- `node test.js` – 15 uji logika (rupiah, nilai lahan, kode proyek, validasi, booking ganda, ringkasan, peran).
- `python3 ui_test.py` – uji browser (Playwright) di lebar HP dan desktop: buat proyek, validasi, simpan setelah reload, tambah unit, service worker, manifest.

## Rencana tahap berikutnya
2 Lahan/kavling/perizinan · 3 RAB/RAP/material/progres · 4 Keuangan/BEP/ROI/laporan · 5 CRM/booking/serah terima · 6 Supabase, RLS, ekspor PDF/Excel, keamanan.
